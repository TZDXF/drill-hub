# 计划、阶段与任务

[API 索引与通用协议](../api.md)。以下响应字段均指成功信封中的 `data`；通用鉴权、错误和并发规则见索引。

| 方法  | 路径                              | scope           | 成功状态 | 说明           |
| ----- | --------------------------------- | --------------- | -------- | -------------- |
| GET   | `/api/v1/agent/topics/{id}/plans` | `read`          | 200      | 主题计划列表   |
| POST  | `/api/v1/agent/topics/{id}/plans` | `content:write` | 201      | 创建计划       |
| PATCH | `/api/v1/agent/plans/{id}`        | `content:write` | 200      | 整体修改计划   |
| PATCH | `/api/v1/agent/tasks/{id}`        | `content:write` | 200      | 修改或移动任务 |

## 响应字段

列表返回 `LearningPlan[]`；创建、修改计划返回 `LearningPlan`；修改任务只返回 `LearningTask`，不返回父计划的新 revision。

**LearningPlan**

- [通用记录字段](../api.md#通用记录字段)。
- `topicId`: string — 所属主题 ID。
- `title`: string — 计划标题。
- `phases`: PlanPhase[] — 有序阶段。

**PlanPhase**

- `id`: string；`title`: string；`tasks`: LearningTask[]（有序）。

**LearningTask**

- `id`: string；`title`: string。
- `kind`: `reading|practice|exam|manual`。
- `targetId`: string | null — 引用内容或评估；manual 无目标。
- `scheduledDate`: string | null — `YYYY-MM-DD`。
- `estimatedMinutes`: integer | null。
- `status`: `todo|in_progress|completed`。
- `completedAt`: string | null — 服务端维护，不作为可自由写入的事实字段。

列表支持 `archiveState=active|archived|all`，默认 `active`。修改任务后如要继续写入，重新列出父计划读取最新 revision。

## 请求与约束

创建：

```http
POST /api/v1/agent/topics/{topicId}/plans
```

```json
{
  "title": "第一周",
  "phases": [
    {
      "title": "基础阅读",
      "tasks": [
        {
          "title": "阅读事务笔记",
          "kind": "reading",
          "targetId": "{contentId}",
          "scheduledDate": "2026-10-20",
          "estimatedMinutes": 30
        }
      ]
    }
  ]
}
```

- `title`：必填，最多 500 字符。
- `phases`：可省略，最多 100 个阶段。
- 阶段：可选已有 `id`；新阶段用 `title` 创建。
- 阶段内 `tasks` 可省略，最多 500 项。
- 任务：`title`、`kind` 必填；`targetId`、`scheduledDate`、`estimatedMinutes` 可选。
- `kind`：`reading`、`practice`、`exam`、`manual`。
- `scheduledDate`：`YYYY-MM-DD` 或 `null`。
- `estimatedMinutes`：正整数、最多 100000，或 `null`。
- 新任务只能 `todo`，且不能提供非空 `completedAt`。
- `reading.targetId` 必须引用同主题内容；`practice`/`exam.targetId` 必须引用同主题且同类型的评估；`manual.targetId` 必须为 `null`/省略。

修改计划：

```http
PATCH /api/v1/agent/plans/{id}
```

```json
{
  "expectedRevision": 1,
  "phases": [
    {
      "id": "{existingPhaseId}",
      "title": "基础阅读",
      "tasks": [
        {
          "id": "{existingTaskId}",
          "title": "阅读事务笔记",
          "kind": "reading",
          "targetId": "{contentId}",
          "status": "todo"
        }
      ]
    }
  ]
}
```

- `expectedRevision` 必填；`title` 和 `phases` 至少提供一个。
- `phases` 是完整的新结构；保留已有 ID 才能复用阶段、任务状态与完成历史。
- 不能复用未知 ID。
- 已开始或已完成的任务不能更改 `kind`/`targetId`，也不能从计划中删除。
- 已归档计划不能修改。

单独修改/移动任务：

```http
PATCH /api/v1/agent/tasks/{taskId}
```

```json
{
  "expectedRevision": 3,
  "title": "复习事务笔记",
  "status": "in_progress",
  "phaseId": "{targetPhaseId}",
  "position": 0
}
```

- `expectedRevision` 是父计划 revision。
- 可更新 `title`、`scheduledDate`、`estimatedMinutes`、`status`。
- 要移动时必须提供 `phaseId`；`position` 可选，必须落在目标阶段的可插入范围内。只给 `position` 不给 `phaseId` 会失败。
- 状态只能是 `todo`、`in_progress`、`completed`。`practice`/`exam` 任务只能由对应作答交卷自动完成，Agent 直接将未完成此类任务改为 `completed` 会返回 `409 TASK_KIND_NOT_COMPLETABLE`；改回其他状态会清空 `completedAt`。
