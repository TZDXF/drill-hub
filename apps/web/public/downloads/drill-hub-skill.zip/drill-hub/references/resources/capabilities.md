# 能力发现

[API 索引与通用协议](../api.md)。以下响应字段均指成功信封中的 `data`；通用鉴权、错误和并发规则见索引。

| 方法 | 路径                         | scope  | 成功状态 | 说明                   |
| ---- | ---------------------------- | ------ | -------- | ---------------------- |
| GET  | `/api/v1/agent/capabilities` | `read` | 200      | 读取当前能力与令牌权限 |

## 响应字段

- `apiVersion`: integer — 当前 API 版本为 `1`。
- `scopes`: string[] — 当前令牌实际拥有的权限，不代表所有可能权限。
- `questionTypes`: string[] — `single_choice`、`multiple_choice`、`true_false`、`fill_blank`、`short_answer`。
- `gradingModes`: string[] — `rule`、`model_rubric`、`external_rubric`。
- `limitations`: string[] — 服务端描述的当前限制。

## 调用

```http
GET /api/v1/agent/capabilities
```

建议接入后先读取一次。能力响应不是完整路由文档；使用已记录的请求字段，不要从描述推断不存在的接口。
