# 学习摘要、作答与错题

[API 索引与通用协议](../api.md)。以下响应字段均指成功信封中的 `data`；通用鉴权、错误和并发规则见索引。

| 方法  | 路径                                                 | scope           | 成功状态 | 说明             |
| ----- | ---------------------------------------------------- | --------------- | -------- | ---------------- |
| GET   | `/api/v1/agent/learning-summary`                     | `read`          | 200      | 增量学习摘要     |
| GET   | `/api/v1/agent/attempts`                             | `read`          | 200      | 作答列表         |
| GET   | `/api/v1/agent/attempts/{id}`                        | `read`          | 200      | 作答详情         |
| GET   | `/api/v1/agent/wrong-questions`                      | `read`          | 200      | 错题列表         |
| PATCH | `/api/v1/agent/wrong-questions/{questionId}/mastery` | `content:write` | 200      | 更新错题掌握状态 |

## 响应字段

**学习摘要**：`{ topics: Topic[], plans: LearningPlan[], recentAttempts: Attempt[], wrongQuestions: WrongQuestion[] }`。

**Attempt**（列表返回数组，详情返回单个）

- `id`、`createdAt`、`updatedAt`、`revision`、`ownerId`。
- `topicId`: string；`assessmentId`: string | null；`answerLinkId`: string | null；`title`: string；`kind`: `practice|exam`。
- `status`: `in_progress|pending_grading|completed`。
- `startedAt`: string；`expiresAt`: string | null；`submittedAt`: string | null。
- `submissionReason`: `user_submitted|time_expired` | null。
- `items`: AttemptItemSnapshot[]。

**AttemptItemSnapshot**

- `id`: string；`questionId`: string；`questionVersion`: integer。
- `definition`: [QuestionDefinition](questions.md) — 冻结题目，包括答案键和 rubric。
- `maxScore`: string；`answer`: Answer | null；`answerRevision`: integer。
- `lockedAt`: string | null；`generation`: integer。
- `gradingStatus`: `unanswered|pending|running|failed|completed`。
- `grade`: [GradeResult](grading.md#评分结果) | null；`gradingHistory`: GradeResult[]。
- `Answer` 按题型为 `{ optionId: string }`、`{ optionIds: string[] }`、`{ value: boolean }`、`{ slots: Record<string, string> }` 或 `{ text: string }`。

**WrongQuestion**（列表返回数组，修改返回单个）

- `id`、`createdAt`、`updatedAt`、`revision`、`ownerId`。
- `topicId`: string；`questionId`: string。
- `masteryStatus`: `pending|reviewing|mastered`。
- `lastWrongAt`: string；`lastPracticedAt`: string；`wrongCount`: integer。

Agent 错题列表只返回上述记录，不包含学习端附加的题干投影。

## 查询参数

| 路由             | 可选查询                            | 语义                                                                              |
| ---------------- | ----------------------------------- | --------------------------------------------------------------------------------- |
| learning-summary | `since`                             | 可解析的 ISO 时间；分别返回各表 `updatedAt >= since` 的记录（含归档），不是事件流 |
| attempts         | `status`、`topicId`、`assessmentId` | 精确匹配，可组合；status 取上述作答状态                                           |
| wrong-questions  | `topicId`、`masteryStatus`          | 精确匹配，可组合                                                                  |

以上接口不使用 `archiveState`，不支持分页，也不承诺额外排序。摘要中的 `recentAttempts` 不代表限量的最近 N 条。

`GET /agent/attempts` 还会返回本人评估通过临时答题链接产生的匿名作答，可通过非空 `answerLinkId` 识别；`learning-summary.recentAttempts` 不包含这些作答。它们不会写入本人的错题列表。

不要假设有推送或 Webhook。只在用户需要时读取：

```http
GET /api/v1/agent/learning-summary?since=2026-10-01T00:00:00Z
```

`since` 可选、必须是可解析时间；筛选 `updatedAt >= since` 的主题、计划、近期作答和错题。

```http
GET /api/v1/agent/attempts?status=pending_grading&topicId={topicId}
```

支持 `status`、`topicId`、`assessmentId` 过滤，但当前返回全部匹配项，没有分页。

```http
GET /api/v1/agent/attempts/{id}
```

返回冻结的 `Attempt`：`items[].definition`（含 rubric/评分键）、`answer`、`gradingStatus`、`grade`、`gradingHistory`、`generation` 等。

- `gradingStatus`：`unanswered`、`pending`、`running`、`failed`、`completed`。
- 模型评分未完成时 `grade` 可能为 `null`；不要把 `null` 当作 0 分。
- `completed` 且 `grade.version` 为当前有效评分；重评历史在 `gradingHistory`。
- `attempt.status`：`in_progress`、`pending_grading`、`completed`。
- Agent 没有单独的 `/agent/attempts/{id}/report`；如用户还持有学习者会话并需要汇总 `awardedScore`/`isFinal`，可使用学习者路由 `/api/v1/attempts/{id}/report`，但不要用 Agent 令牌调用。

## 修改错题掌握状态

```http
PATCH /api/v1/agent/wrong-questions/{questionId}/mastery
```

```json
{
  "expectedRevision": 1,
  "masteryStatus": "reviewing"
}
```

路径参数是 `questionId`，不是错题记录 `id`。`expectedRevision` 则是错题记录的 revision，必须是当前版本。`masteryStatus` 必填且只能是 `pending`、`reviewing`、`mastered`；成功返回更新后的错题记录。
